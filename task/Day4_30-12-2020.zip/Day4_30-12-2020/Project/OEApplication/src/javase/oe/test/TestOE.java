/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.oe.test;

import javase.oe.customers.Company;
import javase.oe.customers.Customer;
import javase.oe.products.Hardware;
import javase.oe.products.Software;

/**
 *
 * @author Administrator
 */
public class TestOE {
    public static void main(String[] args) {
         Software softwareOSWin10 = new Software(1, "OS Win 10",200, "OS Ms", "123-12312312");
         Hardware hardwarePrinterXerox = new Hardware(2, "Xerox Printer", 500, "Printers", 3);
         Hardware hardwareCanonScanner = new Hardware(3, "Cannon scanner", 400, "Scanners", 5);
         
         Company Raya = new Company(401, "Rayaa", "012312312", "Cairo", "Ahmed Ibrahim", 10);
         
         //////////////////////
      /*   
         Order order1001 = new Order(1001);
         order1001.setCustomer(Raya);
         
         order1001.addProductToOrder(softwareOSWin10);
         order1001.addProductToOrder(softwareOSWin10);
         order1001.addProductToOrder(hardwarePrinterXerox);
         order1001.addProductToOrder(hardwarePrinterXerox);
         order1001.addProductToOrder(hardwarePrinterXerox);
         order1001.addProductToOrder(hardwareCanonScanner);
      
      
         
         ///////////////// printing order and all data
         order1001.printOrderDetails();
         
        */
        
        
    }
    
}
