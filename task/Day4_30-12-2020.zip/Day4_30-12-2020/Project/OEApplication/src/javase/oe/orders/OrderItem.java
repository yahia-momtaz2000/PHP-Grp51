/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.oe.orders;

import javase.oe.products.Hardware;
import javase.oe.products.Product;

/**
 *
 * @author Administrator
 */
public class OrderItem {
     private int lineNbr;
     private Product product;
     private int quantity;

    public OrderItem(Product product) {
        this.product = product;
    }

    public int getLineNbr() {
        return lineNbr;
    }

    public void setLineNbr(int lineNbr) {
        this.lineNbr = lineNbr;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
    
    // get price of the product
    public double getUnitPrice(){
          return product.getProductRetailPrice();
    }
    
    public double getItemTax(){
       // calc tax value of the product ??
       // 0   software or manual  |    value ??  Hardware
          if(product instanceof Hardware){
              // there is tax
               // call getTax() in Hardware class 
                 Hardware d = (Hardware)product;
               return d.getTax( getUnitPrice() * quantity );
          }else{
               // no tax 
              return 0;
          }
        
    }
    
    
     
}
