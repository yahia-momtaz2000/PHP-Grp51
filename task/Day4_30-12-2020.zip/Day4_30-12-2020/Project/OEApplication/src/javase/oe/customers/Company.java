/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.oe.customers;

/**
 *
 * @author Administrator
 */
public class Company extends Customer{
     private String contactPerson;
     private int discount;

    public Company( int customerId, String customerName, String customerPhone, String customerAddress,
            String contactPerson, int discount) {
        super(customerId, customerName, customerPhone, customerAddress);
        this.contactPerson = contactPerson;
        this.discount = discount;
    }

    public String getContactPerson() {
        return contactPerson;
    }

    public void setContactPerson(String contactPerson) {
        this.contactPerson = contactPerson;
    }

    public int getDiscount() {
        return discount;
    }

    public void setDiscount(int discount) {
        this.discount = discount;
    }
     
     
    
}
