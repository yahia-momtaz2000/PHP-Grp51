/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.oe.test;


/**
 *
 * @author Administrator
 */
public class Draft {
/*
    public void printOrderDetails(){
         System.out.println("************************ Order Data ***************************");
         System.out.println("Order Id : "+getOrderId());
         System.out.println("Order Date : "+getOrderDate());
         System.out.println("Customer name : "+getCustomer().getCustomerName());
         System.out.println("Order Total : "+getOrderTotal()); // 0
         
         System.out.println("------------------------- Order lines ------------------------------");
          for(OrderItem item : orderItemsList){
              System.out.println("item name : "+item.getProduct().getProductName());
              System.out.println("Unit Price "+item.getUnitPrice());
              System.out.println("Item Qty : "+item.getQuantity());
              System.out.println("Item Tax value : "+item.getItemTax());
              System.out.println("Item Line Total : "+item.getItemTotal());
              System.out.println("----------------------");
          }
*/
    }
