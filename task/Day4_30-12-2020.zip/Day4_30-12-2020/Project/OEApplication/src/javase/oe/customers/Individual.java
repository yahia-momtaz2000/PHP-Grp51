/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.oe.customers;

/**
 *
 * @author Administrator
 */
public class Individual extends Customer{
    private String licNumber;

    public Individual(int customerId, String customerName, String customerPhone, String customerAddress, String licNumber) {
        super(customerId, customerName, customerPhone, customerAddress);
        this.licNumber = licNumber;
    }

    public String getLicNumber() {
        return licNumber;
    }

    public void setLicNumber(String licNumber) {
        this.licNumber = licNumber;
    }

    @Override
    public String toString() {
        return "This is the individual Object named : "+getCustomerName();
    }
    
    
    
    
}
