/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javase.oe.products;

import javase.oe.interfaces.Taxable;

/**
 *
 * @author Administrator
 */
public class Hardware extends Product implements Taxable{
    private int warrantyPeriod;

    public Hardware(int productId, String productName, double productRetailPrice, String productDescription, int warrantyPeriod) {
        super(productId, productName, productRetailPrice, productDescription);
        this.warrantyPeriod = warrantyPeriod;
    }

    public int getWarrantyPeriod() {
        return warrantyPeriod;
    }

    public void setWarrantyPeriod(int warrantyPeriod) {
        this.warrantyPeriod = warrantyPeriod;
    }

    @Override
    public double getTax(double amount) {
         return amount * Taxable.TAX_PERC / 100.0;
    }

 
 
    
}
